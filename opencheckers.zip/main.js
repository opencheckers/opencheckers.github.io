FBInstant.initializeAsync()
    .then(function() {
          // Start loading game assets here
        console.log("loaded");
    });
